import express from "express";
import serverless from "serverless-http";
const app = express();
app.use(express.json());
app.get("/health", (req,res) => res.json({ok:true}));
export const handler = serverless(app);
